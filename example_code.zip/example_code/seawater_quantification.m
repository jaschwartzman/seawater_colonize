%This script was written to analyze images of individual chitin particles. 
%Masks are defined for cells and beads. The pixel area occupied by beads and 
%cells on beads is computed The cell patches are assessed to see how well they fit a normal
%distribution. The statistics, and images of the masks and orginal image
%(as read in to MATLAB) are output. A summary of the data is compiled.


clear all
close all 

%change path to wherever the images are
myFolder = '/Users/j/Desktop/Seawater_colonization/example_code';
%put in a specific file name to check parameters
filePattern = fullfile(myFolder, '*.tif'); 
theFiles = dir(filePattern);

%Iterate through the files
for a = 1 : length(theFiles)
    baseFileName = theFiles(a).name;
    fullFileName = fullfile(myFolder, baseFileName);
    fprintf(1, 'Now reading %s\n', fullFileName);
    fname = fullFileName;
    %read in image
    signal = (imread(fullFileName));
    %define the area that is the particle...
    %...first need to get rid of small objects
    se = strel('disk',5);
    signal_mask = imerode(signal,se);
    signal_mask = imdilate(signal_mask,se);
    %...blurring the background and then looking for a change in intensity
    %(gradient) help do this when the signal from be bead is weak.
    signal_mask=imgaussfilt(signal_mask,10);
    signal_mask=imgradient(signal_mask);
    %...we need to remove small features defined by the gradient
    %transformation
    signal_mask = imerode(signal,se);
    signal_mask = imdilate(signal_mask,se);
    %...and fill in holes to build the mask for the bead
    signal_mask = imfill( signal_mask ,'holes');
    %Finally, we'll use an intensity-based threshold to pull out the bead
    maskb =double(signal_mask>1.2*mean2(signal_mask));
    % Make the bead mask binary
    labels = bwlabel(maskb);
    %fill in any remaining holes in the mask
    labels = imfill( labels ,'holes');
    name = baseFileName(1:end-4);
    %Remove objects taht are too small to be beads (this was empirically defined) 
    stats= regionprops(labels,'Area','MajorAxisLength');
        for i = 1:length(stats);
            junk=stats(i);
        if junk.Area <5000;
            labels(labels==i)=0;
        end
        if junk.MajorAxisLength >500
            labels(labels==i)=0;
        end
        end      
    labels=bwlabel(labels>0);
    
    clear Areabead
    Areabead=0;
    %Measure the area of the bead (object in label)
    stats= regionprops(labels,'Area');
    for s = 1:length(stats);
        junk3=stats(s);
        Areabead(s) = junk3.Area;
    end
        Areacells_total=[];
        Patches_per_bead=[];
        ptotal=[];
        htotal=[];
        Frac=0;
        
%generate example image for cell mask
signalcell=imgaussfilt(signal,1);
cellsignal=double(signalcell>(max(max(signalcell))/6));
labelscells = bwlabel(cellsignal);    
clear signalcell
clear cellsignal
%Iterate through beads, and find cells in each bead
    for f = 1:max(max(labels))
        temp=double(labels==f);
        signalcell=imgaussfilt(signal,1);
        cellsignal=double(signalcell>(max(max(signalcell))/6));
        cellsignal=temp.*cellsignal;
        labels2 = bwlabel(cellsignal);    
        labels2=bwlabel(labels2>0);
    %Measure the area of each patch of cells
        stats3= regionprops(labels2,'Area');
        clear Areacells
        Areacells=0;
        for j = 1:length(stats3)
            junk2=stats3(j);
            Areacells(j) = junk2.Area;
        end 
        Areacells_total=[Areacells_total sum(Areacells)];
        Patches_per_bead=[Patches_per_bead length(Areacells)];
        Z=NaN;
        h=NaN;
        p=NaN;
        if length(Areacells)>2
            Logcells=log(Areacells);
            Z=normalize(Logcells);
            [h p]= kstest(Z);
        end
        ptotal=[ptotal p];
        htotal=[htotal h];

    end
    
   if Areabead>0
            Frac=Areacells_total./Areabead;  
   end
   if Areabead==0
            Areacells_total=NaN;
            Frac=NaN;
            htotal=NaN;
            ptotal=NaN;
            Frac=NaN;
            Patches_per_bead=NaN;
   end
    
%Output statistics

name = baseFileName(1:end-4);
data_end='_stats.csv';
name2 = strcat(name,data_end);
output = table([Areabead'],[Areacells_total'],[Frac'],[Patches_per_bead'],[htotal'],[ptotal']);
output.Properties.VariableNames = {'Areabead_pixels' 'Areacells_pixels' 'Fraction_area_cells' 'Number of patches' 'KStest_lognormal' 'KS_test_pvalue'};
writetable(output,name2);
%export images of bead mask, cell mask, and image
bead='_beadmask.png';
name3 = strcat(name,bead);
beadmask=imagesc(labels);
saveas(beadmask,name3);
signalend='_signal.png';
name5 = strcat(name,signalend);
signal=imagesc(signal);
saveas(signal,name5);
cell='_cellmask.png';
name4 = strcat(name,cell);
cellmask=imagesc(labelscells);
saveas(cellmask,name4);
end

